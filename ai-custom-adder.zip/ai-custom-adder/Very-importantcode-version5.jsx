import { useState, useEffect } from 'react';
import PyramidComponent from './PyramidComponent';
import AdderComponent from './AdderComponent';
import { loadCSV } from '../utils/csvLoader';
import axios from 'axios';

const MainComponent = () => {
  const [pyramid, setPyramid] = useState([
                                  ['1'],
                             ['1', '1', '1'],
                        ['1', '1', '1', '1', '1'],
                   ['1', '1', '1', '1', '1', '1', '1'],
              ['1', '1', '1', '1', '1', '1', '1', '1', '1'], 
         ['1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1'], 
    ['1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 'X'] 
  ]);
  const [adder, setAdder] = useState([]);
  const [customAdders, setCustomAdders] = useState([]);
  const [selectedAdders, setSelectedAdders] = useState([]);
  const [error, setError] = useState(null);
  const [log, setLog] = useState([]);

  const OPENAI_API_KEY = 'sk-proj-wy1Ew0lbAwyZ5lLZwslRT3BlbkFJ21ZajS4D6LqBJsz8A41G';

  useEffect(() => {
    fetch('/src/assets/lookup_table.csv')
      .then((response) => response.text())
      .then((csvText) => {
        loadCSV(csvText, (data) => {
          if (data.length === 0) {
            setError('No custom adders loaded from CSV');
          } else {
            setCustomAdders(data);
            addToLog('Loaded custom adders: ' + data.length);
          }
        });
      })
      .catch((error) => {
        console.error('Error fetching or parsing CSV:', error);
        setError(`Failed to load custom adders: ${error.message}`);
      });
  }, []);

  const addToLog = (message) => {
    setLog(prevLog => [...prevLog, message]);
    console.log(message);
  };

  const visualizePyramid = (pyramid) => {
    const maxWidth = pyramid.length;  // Get the max width for padding
    return pyramid.map((row, index) => {
      const spaces = ' '.repeat(maxWidth - index - 1);  // Calculate leading spaces
      return spaces + row.join('');  // Prepend spaces and join the row
    }).join('\n');  // Join all rows with newline
  };
  

  const applyAdderToPyramid = (pyramid, adderData, row, col) => {
    let newPyramid = JSON.parse(JSON.stringify(pyramid));
    let appliedSuccessfully = false;

    for (let i = 0; i < adderData.length; i++) {
      const height = Array.isArray(adderData[i]) ? adderData[i][0] : adderData[i];
      // console.log('height',height);
      for (let j = 0; j < height; j++) {
        if (row - j >= 0 && col - i >= 0 && newPyramid[row - j][col - i] === '1') {
          newPyramid[row - j][col - i] = '0';
          console.log(row-j, col-i);
          appliedSuccessfully = true;
        }

      }
      console.log('row: ')
    }

    return { newPyramid, appliedSuccessfully };
  };

  const shrinkPyramid = (pyramid) => {
    let newPyramid = [];
    for (let col = 0; col < pyramid[pyramid.length - 1].length; col++) {
      let newColumn = [];
      for (let row = pyramid.length - 1; row >= 0; row--) {
        if (pyramid[row][col] && pyramid[row][col] !== '0') {
          newColumn.unshift(pyramid[row][col]);
        }
      }
      if (newColumn.length > 0) {
        while (newColumn.length < pyramid.length) {
          newColumn.unshift(' ');
        }
        for (let i = 0; i < newColumn.length; i++) {
          if (!newPyramid[i]) newPyramid[i] = [];
          newPyramid[i].push(newColumn[i]);
        }
      }
    }
    return newPyramid.filter(row => row.some(cell => cell !== ' '));
  };

  const isPyramidCovered = (pyramid) => {
    return pyramid.every(row => row.every(bit => bit === '0' || bit === 'X' || bit === ' '));
  };

  const findValidStartPositions = (pyramid) => {
    let positions = [];
    for (let row = pyramid.length - 1; row >= 0; row--) {
      for (let col = pyramid[row].length - 2; col >= 0; col--) {  // Start from second-last column to avoid 'X'
        if (pyramid[row][col] === '1') {
          positions.push({ row, col });
        }
      }
      if (positions.length > 0) break;  // Only consider the bottommost row with '1's
    }
    return positions;
  };

  const selectBestAdder = async (currentPyramid, availableAdders) => {
    try {
      const validPositions = findValidStartPositions(currentPyramid);
      if (validPositions.length === 0) {
        return null; // No valid positions found
      }

      addToLog('Sending request to OpenAI API...');
      addToLog('Current pyramid:\n' + visualizePyramid(currentPyramid));
      addToLog('Valid start positions: ' + JSON.stringify(validPositions));
      addToLog('Available adders: ' + availableAdders.length);

      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-4-turbo',
          messages: [
            {
              role: 'system',
              content: 'You are an AI assistant that selects the best custom adder and its position for a given partial product pyramid. The goal is to cover the most 1s in the pyramid efficiently, starting from the right side (but not including the rightmost "X"). Respond only with a valid JSON object.'
            },
            {
              role: 'user',
              content: `Given the current pyramid state:\n${visualizePyramid(currentPyramid)}\nValid start positions: ${JSON.stringify(validPositions)}, and the following available custom adders: ${JSON.stringify(availableAdders)}, select the best custom adder and its position that covers the most 1s in the pyramid efficiently. The adder shape is interpreted as columns from right to left, where each number represents the height of a column. The adder must start at one of the valid start positions where there's still a 1, and it should be placed to maximize coverage without going out of bounds or covering 'X' cells. Consider the cost of the adder in your decision. Respond with a JSON object containing "adderIndex" (index of the best adder in the availableAdders array), "row" (bottom row where the adder should be placed, 0-indexed), and "col" (rightmost column where the adder should start, 0-indexed).`
            }
          ],
          temperature: 0.1,
          max_tokens: 500
        },
        {
          headers: {
            'Authorization': `Bearer ${OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      );

      addToLog('Raw API Response: ' + response.data.choices[0].message.content);

      let cleanedResponse = response.data.choices[0].message.content.replace(/```json\n|\n```/g, '');
      let selectedAdderInfo = JSON.parse(cleanedResponse);

      if (typeof selectedAdderInfo.adderIndex !== 'number' || selectedAdderInfo.adderIndex < 0 || selectedAdderInfo.adderIndex >= availableAdders.length) {
        throw new Error('Invalid adder index in API response');
      }

      let selectedAdder = { ...availableAdders[selectedAdderInfo.adderIndex] };
      selectedAdder.row = selectedAdderInfo.row;
      selectedAdder.col = selectedAdderInfo.col;

      addToLog('Selected adder: ' + JSON.stringify(selectedAdder));
      return selectedAdder;
    } catch (error) {
      addToLog('Error in selectBestAdder: ' + error.message);
      return null;
    }
  };

  const fetchCustomAdder = async () => {
    if (customAdders.length === 0) {
      setError('No custom adders available');
      return;
    }

    try {
      let currentPyramid = [...pyramid];
      let allSelectedAdders = [];
      let remainingAdders = [...customAdders];

      while (!isPyramidCovered(currentPyramid) && remainingAdders.length > 0) {
        let bestAdder = await selectBestAdder(currentPyramid, remainingAdders);

        if (bestAdder) {
          const { newPyramid, appliedSuccessfully } = applyAdderToPyramid(currentPyramid, bestAdder.data, bestAdder.row, bestAdder.col);
          if (appliedSuccessfully) {
            allSelectedAdders.push(bestAdder);
            addToLog('Applied adder: ' + JSON.stringify(bestAdder));
            addToLog('Pyramid with zeros:\n' + visualizePyramid(newPyramid));
            currentPyramid = shrinkPyramid(newPyramid);
            addToLog('Shrunk pyramid:\n' + visualizePyramid(currentPyramid));
          } else {
            addToLog('Adder could not be applied: ' + JSON.stringify(bestAdder));
          }
          
          remainingAdders = remainingAdders.filter(adder => 
            !(adder.data.every((val, idx) => val === bestAdder.data[idx]) && adder.cost === bestAdder.cost)
          );
        } else {
          addToLog('Failed to select a compatible adder.');
          break;
        }
      }

      if (allSelectedAdders.length > 0) {
        setAdder(allSelectedAdders[allSelectedAdders.length - 1].data.map(v => Array.isArray(v) ? v[0] : v));
        setSelectedAdders(allSelectedAdders);
        setPyramid(currentPyramid);
      } else {
        setError('No adders were selected.');
      }
    } catch (error) {
      addToLog('Error in fetchCustomAdder: ' + error.message);
      setError(`Failed to fetch custom adder: ${error.message}`);
    }
  };

  return (
    <div className="main-container">
      <h1>Custom Adder Visualizer</h1>
      {error && <div style={{color: 'red'}}>{error}</div>}
      <PyramidComponent levels={pyramid} />
      {adder.length > 0 && (
        <AdderComponent adder={adder} applyAdder={() => {}} />
      )}
      <button onClick={fetchCustomAdder}>Fetch Custom Adder</button>
      {selectedAdders.length > 0 && (
        <div>
          <h2>Selected Adders:</h2>
          <ul>
            {selectedAdders.map((selectedAdder, index) => (
              <li key={index}>
                Cost: {selectedAdder?.cost ?? 'N/A'}, Adder Data: {JSON.stringify(selectedAdder?.data ?? [])}, 
                Position: Row {selectedAdder?.row ?? 'N/A'}, Col {selectedAdder?.col ?? 'N/A'}
              </li>
            ))}
          </ul>
        </div>
      )}
      <div>
        <h2>Process Log:</h2>
        <pre>
          {log.join('\n')}
        </pre>
      </div>
    </div>
  );
};

export default MainComponent;