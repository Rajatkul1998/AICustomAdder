import PropTypes from 'prop-types';

const AdderComponent = ({ adder, applyAdder }) => {
  return (
    <div className="adder">
      <h3>Custom Adder</h3>
      <div className="adder-grid">
        {adder.map((value, index) => (
          <div 
            key={index} 
            className="adder-cell" 
            style={{
              width: '20px',
              height: '20px',
              backgroundColor: value > 0 ? 'black' : 'white',
              border: '1px solid #000',
              display: 'inline-block',
              margin: '2px'
            }}
          />
        ))}
      </div>
      <button onClick={applyAdder}>Apply Adder</button>
    </div>
  );
};

AdderComponent.propTypes = {
  adder: PropTypes.arrayOf(PropTypes.number).isRequired,
  applyAdder: PropTypes.func.isRequired,
};

export default AdderComponent;
