import PropTypes from 'prop-types';

const PyramidComponent = ({ levels }) => {
  return (
    <div className="pyramid">
      {levels.map((level, rowIndex) => (
        <div key={rowIndex} className="pyramid-row">
          {level.map((bit, colIndex) => (
            <span 
              key={`${rowIndex}-${colIndex}`} 
              className={`pyramid-bit ${bit === '1' ? 'one' : bit === 'c' ? 'carry' : 'zero'}`}
            >
              {bit}
            </span>
          ))}
        </div>
      ))}
    </div>
  );
};

PyramidComponent.propTypes = {
  levels: PropTypes.arrayOf(PropTypes.arrayOf(PropTypes.string)).isRequired,
};

export default PyramidComponent;