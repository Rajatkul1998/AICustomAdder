export const loadCSV = (csvText, callback) => {
  const lines = csvText.trim().split('\n');
  const result = [];

  if (lines.length < 2) {
    console.error('CSV file is empty or has no data rows');
    callback([]);
    return;
  }

  const header = lines[0].split(',');
  if (header.length !== 9) {
    console.error('CSV header does not have the expected 9 columns');
    callback([]);
    return;
  }

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',');
    if (cols.length === 9) {
      // Extract the elements from index 0 to 5, filter out 0s, and reverse them
      const data = cols.slice(0, 5)
                       .map(Number)
                       .filter(num => num !== 0)
                       .reverse();
      const cost = parseInt(cols[8], 10);

      if (!isNaN(cost)) {
        result.push({ data, cost });
      } else {
        console.warn(`Invalid cost in row ${i}: ${cols[8]}`);
      }
    } else {
      console.warn(`Row ${i} does not have 9 columns: ${lines[i]}`);
    }
  }

  callback(result);
};
