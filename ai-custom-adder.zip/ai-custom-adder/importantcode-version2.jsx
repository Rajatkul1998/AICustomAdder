import { useState, useEffect } from 'react';
import PyramidComponent from './PyramidComponent';
import AdderComponent from './AdderComponent';
import { loadCSV } from '../utils/csvLoader';
import axios from 'axios';

const MainComponent = () => {
  const [pyramid, setPyramid] = useState([
    [1],
    [1, 1, 1],
    [1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1]
  ]);
  const [adder, setAdder] = useState([]);
  const [customAdders, setCustomAdders] = useState([]);
  const [selectedAdders, setSelectedAdders] = useState([]);
  const [error, setError] = useState(null);

  const OPENAI_API_KEY = 'sk-proj-wy1Ew0lbAwyZ5lLZwslRT3BlbkFJ21ZajS4D6LqBJsz8A41G';

  useEffect(() => {
    fetch('/src/assets/lookup_table.csv')
      .then((response) => response.text())
      .then((csvText) => {
        loadCSV(csvText, (data) => {
          if (data.length === 0) {
            setError('No custom adders loaded from CSV');
          } else {
            setCustomAdders(data);
            console.log('Loaded custom adders:', data);
          }
        });
      })
      .catch((error) => {
        console.error('Error fetching or parsing CSV:', error);
        setError(`Failed to load custom adders: ${error.message}`);
      });
  }, []);

  const fetchCustomAdder = async () => {
    if (customAdders.length === 0) {
      setError('No custom adders available');
      return;
    }
  
    try {
      let currentPyramid = [...pyramid];
      let allSelectedAdders = [];
      let iterationCount = 0;
      const maxIterations = 10;
  
      while (!isPyramidCovered(currentPyramid) && iterationCount < maxIterations) {
        console.log(`Iteration ${iterationCount + 1}:`);
        console.log('Current pyramid:', currentPyramid);
        
        const bestAdder = await selectBestAdder(currentPyramid, customAdders);
        if (bestAdder) {
          console.log('Selected adder:', bestAdder);
          allSelectedAdders.push(bestAdder);
          currentPyramid = applyAdderToPyramid(currentPyramid, bestAdder.data);
          console.log('Updated pyramid:', currentPyramid);
        } else {
          console.log('Failed to select a compatible adder.');
          break;
        }
        iterationCount++;
      }
  
      if (allSelectedAdders.length > 0) {
        setAdder(allSelectedAdders[allSelectedAdders.length - 1].data);
        setSelectedAdders(allSelectedAdders);
        setPyramid(currentPyramid);
      } else {
        setError('No adders were selected.');
      }
    } catch (error) {
      console.error('Error in fetchCustomAdder:', error);
      setError(`Failed to fetch custom adder: ${error.message}`);
    }
  };


  const selectBestAdder = async (currentPyramid, availableAdders) => {
    try {
      console.log('Sending request to OpenAI API...');
  
      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-4-turbo',
          messages: [
            {
              role: 'system',
              content: 'You are an AI assistant that selects the best custom adder for a given partial product pyramid. Your response should be in JSON format with "data" (array of 8 numbers representing the adder) and "cost" (number) keys.'
            },
            {
              role: 'user',
              content: `Given the current pyramid state: ${JSON.stringify(currentPyramid)} and the available custom adders: ${JSON.stringify(availableAdders)}, select the best custom adder that covers the most 1s in the pyramid while minimizing cost. The adder should be placed at the rightmost possible position where it can cover 1s. Consider carry bits when selecting the adder. Respond ONLY with a JSON object containing "data" and "cost" keys.`
            }
          ],
          temperature: 0.3,
          max_tokens: 150
        },
        {
          headers: {
            'Authorization': `Bearer ${OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      );
  
      console.log('Raw API Response:', response.data.choices[0].message.content);
  
      let selectedAdder = response.data.choices[0].message.content;
  
      // Remove any non-JSON characters from the beginning and end of the string
      selectedAdder = selectedAdder.replace(/^[^{]*|[^}]*$/g, '');
  
      console.log('Cleaned response:', selectedAdder);
  
      // Attempt to parse the JSON
      try {
        selectedAdder = JSON.parse(selectedAdder);
      } catch (parseError) {
        console.error('Error parsing JSON response:', parseError);
        
        // If parsing fails, attempt to manually extract the data
        const dataMatch = selectedAdder.match(/"data":\s*(\[[^\]]+\])/);
        const costMatch = selectedAdder.match(/"cost":\s*(\d+)/);
        
        if (dataMatch && costMatch) {
          selectedAdder = {
            data: JSON.parse(dataMatch[1]),
            cost: parseInt(costMatch[1], 10)
          };
        } else {
          throw new Error('Failed to extract adder data from API response');
        }
      }
  
      if (!selectedAdder || !Array.isArray(selectedAdder.data) || typeof selectedAdder.cost !== 'number') {
        console.error('Invalid adder format:', selectedAdder);
        throw new Error('Invalid adder format in API response');
      }
  
      console.log('Selected adder:', selectedAdder);
      return selectedAdder;
    } catch (error) {
      console.error('Error in selectBestAdder:', error);
      throw error;
    }
  };

  const isPyramidCovered = (pyramid) => {
    return pyramid.every(row => row.every(bit => bit === 0));
  };

  const applyAdderToPyramid = (pyramid, adderData) => {
    let newPyramid = JSON.parse(JSON.stringify(pyramid));
    let carryBits = [];

    // Apply adder
    for (let i = 0; i < adderData.length; i++) {
      if (adderData[i] > 0 && newPyramid[i]) {
        for (let j = 0; j < adderData[i] && j < newPyramid[i].length; j++) {
          if (newPyramid[i][j] === 1) {
            newPyramid[i][j] = 0;
            if (j === adderData[i] - 1) {
              carryBits.push({ row: i + 1, col: 0 });
            }
          }
        }
      }
    }

    // Apply carry bits
    while (carryBits.length > 0) {
      const carry = carryBits.shift();
      if (newPyramid[carry.row]) {
        if (carry.col >= newPyramid[carry.row].length) {
          if (newPyramid[carry.row + 1]) {
            carryBits.push({ row: carry.row + 1, col: 0 });
          }
        } else if (newPyramid[carry.row][carry.col] === 1) {
          newPyramid[carry.row][carry.col] = 0;
          carryBits.push({ row: carry.row, col: carry.col + 1 });
        } else {
          newPyramid[carry.row][carry.col] = 1;
        }
      }
    }

    return newPyramid;
  };

  const applyAdder = () => {
    setPyramid(prevPyramid => applyAdderToPyramid(prevPyramid, adder));
  };

  return (
    <div className="main-container">
      <h1>Custom Adder Visualizer</h1>
      {error && <div style={{color: 'red'}}>{error}</div>}
      <PyramidComponent levels={pyramid} />
      {adder.length > 0 && (
        <AdderComponent adder={adder} applyAdder={applyAdder} />
      )}
      <button onClick={fetchCustomAdder}>Fetch Custom Adder</button>
      {selectedAdders.length > 0 && (
        <div>
          <h2>Selected Adders:</h2>
          <ul>
            {selectedAdders.map((selectedAdder, index) => (
              <li key={index}>
                Cost: {selectedAdder?.cost ?? 'N/A'}, Adder Data: {JSON.stringify(selectedAdder?.data ?? [])}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default MainComponent;