import { useState, useEffect } from 'react';
import PyramidComponent from './PyramidComponent';
import AdderComponent from './AdderComponent';
import { loadCSV } from '../utils/csvLoader';
import axios from 'axios';

const MainComponent = () => {
  const [pyramid, setPyramid] = useState([
    [1],
    [1, 1, 1],
    [1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1]
  ]);
  const [adder, setAdder] = useState([]);
  const [customAdders, setCustomAdders] = useState([]);
  const [selectedAdders, setSelectedAdders] = useState([]);
  const [error, setError] = useState(null);

  const OPENAI_API_KEY = 'sk-proj-wy1Ew0lbAwyZ5lLZwslRT3BlbkFJ21ZajS4D6LqBJsz8A41G';

  useEffect(() => {
    fetch('/src/assets/lookup_table.csv')
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text();
      })
      .then((csvText) => {
        loadCSV(csvText, (data) => {
          if (data.length === 0) {
            setError('No custom adders loaded from CSV');
          } else {
            setCustomAdders(data);
            console.log('Loaded custom adders:', data);
          }
        });
      })
      .catch((error) => {
        console.error('Error fetching or parsing CSV:', error);
        setError(`Failed to load custom adders: ${error.message}`);
      });
  }, []);

  const fetchCustomAdder = async () => {
    if (customAdders.length === 0) {
      setError('No custom adders available');
      return;
    }

    let currentPyramid = [...pyramid];
    let remainingAdders = [...customAdders];
    let allSelectedAdders = [];

    while (remainingAdders.length > 0 && !isPyramidCovered(currentPyramid)) {
      const bestAdder = await selectBestAdder(currentPyramid, remainingAdders);
      if (bestAdder) {
        allSelectedAdders.push(bestAdder);
        currentPyramid = applyAdderToPyramid(currentPyramid, bestAdder.data);
        remainingAdders = remainingAdders.filter(adder => adder !== bestAdder);
      } else {
        setError('Failed to select a compatible adder.');
        break;
      }
    }

    if (allSelectedAdders.length > 0) {
      setAdder(allSelectedAdders[0].data);
      setSelectedAdders(allSelectedAdders);
      setPyramid(currentPyramid);
    } else {
      setError('No adders were selected.');
    }
  };

  const selectBestAdder = async (currentPyramid, availableAdders) => {
    try {
      console.log('Sending request to OpenAI API...');
      console.log('Current pyramid:', currentPyramid);
      console.log('Available adders:', availableAdders);
  
      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-4-turbo',
          messages: [
            {
              role: 'system',
              content: 'You are an AI assistant that only outputs JSON. Do not include any explanation, just return a JSON object.'
            },
            {
              role: 'user',
              content: `Given the current pyramid state: ${JSON.stringify(currentPyramid)} and the available custom adders: ${JSON.stringify(availableAdders)}, select the best custom adder that covers the most 1s in the pyramid while minimizing cost. Return only a JSON object with "data" (array of 8 numbers representing the adder) and "cost" (number) keys.`
            }
          ],
          temperature: 0.3,
          max_tokens: 50
        },
        {
          headers: {
            'Authorization': `Bearer ${OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      );
  
      const responseText = response.data.choices[0].message.content.trim();
      console.log('OpenAI API Raw Response:', responseText);
  
      // Try to extract JSON from the response
      let jsonStart = responseText.indexOf('{');
      let jsonEnd = responseText.lastIndexOf('}') + 1;
  
      if (jsonStart !== -1 && jsonEnd !== -1) {
        const jsonResponse = responseText.slice(jsonStart, jsonEnd);
        const selectedAdder = JSON.parse(jsonResponse);
        console.log('Selected adder:', selectedAdder);
        return selectedAdder;
      } else {
        throw new Error('Failed to extract JSON from the response.');
      }
    } catch (error) {
      console.error('Error selecting best adder:', error);
      if (error.response) {
        console.error('OpenAI API Error Response:', error.response.data);
      }
      setError('Failed to select best adder using OpenAI API');
      return null;
    }
  };
  
  

  const isPyramidCovered = (pyramid) => {
    return pyramid.every(row => row.every(bit => bit === 0));
  };

  const applyAdderToPyramid = (pyramid, adderData) => {
    return pyramid.map((row, i) => 
      row.map((bit, j) => (i < adderData.length && j < adderData[i] && bit === 1) ? 0 : bit)
    );
  };

  const applyAdder = () => {
    setPyramid(prevPyramid => applyAdderToPyramid(prevPyramid, adder));
  };

  return (
    <div className="main-container">
      <h1>Custom Adder Visualizer</h1>
      {error && <div style={{color: 'red'}}>{error}</div>}
      <PyramidComponent levels={pyramid} />
      {adder.length > 0 && (
        <AdderComponent adder={adder} applyAdder={applyAdder} />
      )}
      <button onClick={fetchCustomAdder}>Fetch Custom Adder</button>
      {selectedAdders.length > 0 && (
        <div>
          <h2>Selected Adders:</h2>
          <ul>
            {selectedAdders.map((selectedAdder, index) => (
              <li key={index}>
                Cost: {selectedAdder?.cost ?? 'N/A'}, Adder Data: {JSON.stringify(selectedAdder?.data ?? [])}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default MainComponent;
