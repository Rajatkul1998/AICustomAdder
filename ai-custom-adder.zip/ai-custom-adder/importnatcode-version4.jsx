import { useState, useEffect } from 'react';
import PyramidComponent from './PyramidComponent';
import AdderComponent from './AdderComponent';
import { loadCSV } from '../utils/csvLoader';
import axios from 'axios';

const MainComponent = () => {
  const [pyramid, setPyramid] = useState([
    [1],
    [1, 1, 1],
    [1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1]
  ]);
  const [adder, setAdder] = useState([]);
  const [customAdders, setCustomAdders] = useState([]);
  const [selectedAdders, setSelectedAdders] = useState([]);
  const [error, setError] = useState(null);
  const [log, setLog] = useState([]);

  const OPENAI_API_KEY = 'sk-proj-wy1Ew0lbAwyZ5lLZwslRT3BlbkFJ21ZajS4D6LqBJsz8A41G';

  useEffect(() => {
    fetch('/src/assets/lookup_table.csv')
      .then((response) => response.text())
      .then((csvText) => {
        loadCSV(csvText, (data) => {
          if (data.length === 0) {
            setError('No custom adders loaded from CSV');
          } else {
            setCustomAdders(data);
            addToLog('Loaded custom adders: ' + data.length);
          }
        });
      })
      .catch((error) => {
        console.error('Error fetching or parsing CSV:', error);
        setError(`Failed to load custom adders: ${error.message}`);
      });
  }, []);

  const addToLog = (message) => {
    setLog(prevLog => [...prevLog, message]);
  };

  const selectBestAdder = async (currentPyramid, availableAdders) => {
    try {
      addToLog('Sending request to OpenAI API...');
      addToLog('Current pyramid: ' + JSON.stringify(currentPyramid));
      addToLog('Available adders: ' + availableAdders.length);

      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-4-turbo',
          messages: [
            {
              role: 'system',
              content: 'You are an AI assistant that selects the best custom adder for a given partial product pyramid. Respond only with a valid JSON object containing an index.'
            },
            {
              role: 'user',
              content: `Given the current pyramid state: ${JSON.stringify(currentPyramid)} and the following available custom adders: ${JSON.stringify(availableAdders)}, select the best custom adder that covers the most 1s in the pyramid while minimizing cost. The adder should be placed at the leftmost possible position where it can cover 1s, starting from the bottom row. Prioritize covering from bottom-left to top-right. Respond with a JSON object containing only an "index" field, which is the index of the best adder in the availableAdders array.`
            }
          ],
          temperature: 0.3,
          max_tokens: 50
        },
        {
          headers: {
            'Authorization': `Bearer ${OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      );

      addToLog('Raw API Response: ' + response.data.choices[0].message.content);

      let cleanedResponse = response.data.choices[0].message.content.replace(/```json\n|\n```/g, '');
      let selectedAdderIndex = JSON.parse(cleanedResponse).index;

      if (typeof selectedAdderIndex !== 'number' || selectedAdderIndex < 0 || selectedAdderIndex >= availableAdders.length) {
        throw new Error('Invalid adder index in API response');
      }

      let selectedAdder = availableAdders[selectedAdderIndex];
      selectedAdder.position = findBestPosition(currentPyramid, selectedAdder.data);

      addToLog('Selected adder: ' + JSON.stringify(selectedAdder));
      console.log('Selected adder: ' , (selectedAdder));
      return selectedAdder;
    } catch (error) {
      addToLog('Error in selectBestAdder: ' + error.message);
      return fallbackSelectAdder(currentPyramid, availableAdders);
    }
  };

  const findBestPosition = (pyramid, adderData) => {
    let bestPosition = 0;
    let maxCoverage = 0;

    for (let position = 0; position < pyramid[pyramid.length - 1].length; position++) {
      let coverage = calculateCoverage(pyramid, adderData, position);
      if (coverage > maxCoverage) {
        maxCoverage = coverage;
        bestPosition = position;
      }
    }

    return bestPosition;
  };

  const calculateCoverage = (pyramid, adderData, position) => {
    let coverage = 0;
    for (let row = pyramid.length - 1; row >= 0; row--) {
      for (let col = position; col < pyramid[row].length && col - position < adderData.length; col++) {
        if (pyramid[row][col] === 1 && adderData[col - position] === 1) {
          coverage++;
        }
      }
    }
    return coverage;
  };

  const applyAdderToPyramid = (pyramid, adderData, position) => {
    let newPyramid = JSON.parse(JSON.stringify(pyramid));
    let carryBits = new Array(adderData.length).fill(0);

    // Apply adder from bottom to top
    for (let row = pyramid.length - 1; row >= 0; row--) {
      for (let col = 0; col < adderData.length; col++) {
        if (position + col < newPyramid[row].length) {
          let sum = (newPyramid[row][position + col] || 0) + adderData[col] + carryBits[col];
          newPyramid[row][position + col] = sum % 2;
          carryBits[col] = Math.floor(sum / 2);
        }
      }

      // Propagate carry bits to the next row
      if (row > 0) {
        for (let i = 0; i < carryBits.length; i++) {
          if (carryBits[i] && position + i < newPyramid[row - 1].length) {
            newPyramid[row - 1][position + i] = (newPyramid[row - 1][position + i] || 0) + carryBits[i];
            carryBits[i] = 0;
          }
        }
      }
    }

    return newPyramid;
  };

  const isPyramidCovered = (pyramid) => {
    return pyramid.every(row => row.every(bit => bit === 0));
  };

  const fallbackSelectAdder = (currentPyramid, availableAdders) => {
    let bestAdder = null;
    let maxCoverage = 0;

    for (let adder of availableAdders) {
      let position = findBestPosition(currentPyramid, adder.data);
      let coverage = calculateCoverage(currentPyramid, adder.data, position);
      if (coverage > maxCoverage || (coverage === maxCoverage && adder.cost < bestAdder?.cost)) {
        maxCoverage = coverage;
        bestAdder = { ...adder, position };
      }
    }

    addToLog('Fallback selected adder: ' + JSON.stringify(bestAdder));
    return bestAdder;
  };

  const fetchCustomAdder = async () => {
    if (customAdders.length === 0) {
      setError('No custom adders available');
      return;
    }

    try {
      let currentPyramid = [...pyramid];
      let allSelectedAdders = [];
      let remainingAdders = [...customAdders];

      while (!isPyramidCovered(currentPyramid) && remainingAdders.length > 0) {
        const bestAdder = await selectBestAdder(currentPyramid, remainingAdders);
        if (bestAdder) {
          allSelectedAdders.push(bestAdder);
          currentPyramid = applyAdderToPyramid(currentPyramid, bestAdder.data, bestAdder.position);
          addToLog('Applied adder: ' + JSON.stringify(bestAdder));
          addToLog('Updated pyramid: ' + JSON.stringify(currentPyramid));
          console.log(currentPyramid);

          remainingAdders = remainingAdders.filter(adder => 
            !(adder.data.every((val, idx) => val === bestAdder.data[idx]) && adder.cost === bestAdder.cost)
          );
        } else {
          addToLog('Failed to select a compatible adder.');
          break;
        }
      }

      if (allSelectedAdders.length > 0) {
        setAdder(allSelectedAdders[allSelectedAdders.length - 1].data);
        setSelectedAdders(allSelectedAdders);
        setPyramid(currentPyramid);
      } else {
        setError('No adders were selected.');
      }
    } catch (error) {
      addToLog('Error in fetchCustomAdder: ' + error.message);
      setError(`Failed to fetch custom adder: ${error.message}`);
    }
  };

  const applyAdder = () => {
    setPyramid(prevPyramid => applyAdderToPyramid(prevPyramid, adder, 0));
  };

  return (
    <div className="main-container">
      <h1>Custom Adder Visualizer</h1>
      {error && <div style={{color: 'red'}}>{error}</div>}
      <PyramidComponent levels={pyramid} />
      {adder.length > 0 && (
        <AdderComponent adder={adder} applyAdder={applyAdder} />
      )}
      <button onClick={fetchCustomAdder}>Fetch Custom Adder</button>
      {selectedAdders.length > 0 && (
        <div>
          <h2>Selected Adders:</h2>
          <ul>
            {selectedAdders.map((selectedAdder, index) => (
              <li key={index}>
                Cost: {selectedAdder?.cost ?? 'N/A'}, Adder Data: {JSON.stringify(selectedAdder?.data ?? [])}, Position: {selectedAdder?.position ?? 'N/A'}
              </li>
            ))}
          </ul>
        </div>
      )}
      <div>
        <h2>Process Log:</h2>
        <ul>
          {log.map((entry, index) => (
            <li key={index}>{entry}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default MainComponent;