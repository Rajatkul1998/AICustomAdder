import { useState, useEffect } from 'react';
import PyramidComponent from './PyramidComponent';
import AdderComponent from './AdderComponent';
import { loadCSV } from '../utils/csvLoader';
import axios from 'axios';

const MainComponent = () => {
  const [pyramid, setPyramid] = useState([
    [1],
    [1, 1, 1],
    [1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1]
  ]);
  const [adder, setAdder] = useState([]);
  const [customAdders, setCustomAdders] = useState([]);
  const [selectedAdders, setSelectedAdders] = useState([]);
  const [error, setError] = useState(null);

  const OPENAI_API_KEY = 'sk-proj-wy1Ew0lbAwyZ5lLZwslRT3BlbkFJ21ZajS4D6LqBJsz8A41G';

  useEffect(() => {
    fetch('/src/assets/lookup_table.csv')
      .then((response) => response.text())
      .then((csvText) => {
        loadCSV(csvText, (data) => {
          if (data.length === 0) {
            setError('No custom adders loaded from CSV');
          } else {
            setCustomAdders(data);
            console.log('Loaded custom adders:', data);
          }
        });
      })
      .catch((error) => {
        console.error('Error fetching or parsing CSV:', error);
        setError(`Failed to load custom adders: ${error.message}`);
      });
  }, []);


  const selectBestAdder = async (currentPyramid, availableAdders) => {
    try {
      console.log('Sending request to OpenAI API...');
      console.log('Current pyramid:', currentPyramid);
      console.log('Available adders:', availableAdders.length);
  
      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-4-turbo',
          messages: [
            {
              role: 'system',
              content: 'You are an AI assistant that selects the best custom adder for a given partial product pyramid. Respond only with a valid JSON object.'
            },
            {
              role: 'user',
              content: `Given the current pyramid state: ${JSON.stringify(currentPyramid)} and ${availableAdders.length} available custom adders, select the best custom adder that covers the most 1s in the pyramid while minimizing cost. The adder should be placed at the leftmost possible position where it can cover 1s, starting from the bottom row. Prioritize covering from bottom-left to top-right. Respond with a JSON object containing "data" (array of 8 numbers representing the adder), "cost" (number), and "position" (number indicating the leftmost column where the adder should be placed, 0-indexed).`
            }
          ],
          temperature: 0.3,
          max_tokens: 150
        },
        {
          headers: {
            'Authorization': `Bearer ${OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      );
  
      console.log('Raw API Response:', response.data.choices[0].message.content);
  
      // Remove markdown formatting if present
      let cleanedResponse = response.data.choices[0].message.content.replace(/```json\n|\n```/g, '');
  
      let selectedAdder = JSON.parse(cleanedResponse);
  
      if (!selectedAdder || !Array.isArray(selectedAdder.data) || typeof selectedAdder.cost !== 'number' || typeof selectedAdder.position !== 'number') {
        throw new Error('Invalid adder format in API response');
      }
  
      console.log('Selected adder:', selectedAdder);
      return selectedAdder;
    } catch (error) {
      console.error('Error in selectBestAdder:', error);
      throw new Error(`Failed to parse API response: ${error.message}`);
    }
  };


  const applyAdderToPyramid = (pyramid, adderData, position) => {
    let newPyramid = JSON.parse(JSON.stringify(pyramid));
    let carryBit = 0;
  
    for (let row = 0; row < newPyramid.length; row++) {
      for (let col = position; col < newPyramid[row].length && col - position < adderData.length; col++) {
        if (adderData[col - position] === 1) {
          if (newPyramid[row][col] === 1) {
            newPyramid[row][col] = 0;
            carryBit = 1;
          } else if (carryBit === 1) {
            newPyramid[row][col] = 1;
            carryBit = 0;
          }
        } else if (carryBit === 1 && newPyramid[row][col] === 1) {
          newPyramid[row][col] = 0;
          carryBit = 1;
        } else if (carryBit === 1) {
          newPyramid[row][col] = 1;
          carryBit = 0;
        }
      }
      if (carryBit === 1 && row + 1 < newPyramid.length) {
        newPyramid[row + 1][position] = 1;
        carryBit = 0;
      }
    }
  
    return newPyramid;
  };

  const isPyramidCovered = (pyramid) => {
    return pyramid.every(row => row.every(bit => bit === 0));
  };


  const fetchCustomAdder = async () => {
    if (customAdders.length === 0) {
      setError('No custom adders available');
      return;
    }
  
    try {
      let currentPyramid = [...pyramid];
      let allSelectedAdders = [];
      let remainingAdders = [...customAdders];
  
      while (!isPyramidCovered(currentPyramid) && remainingAdders.length > 0) {
        const bestAdder = await selectBestAdder(currentPyramid, remainingAdders);
        if (bestAdder) {
          allSelectedAdders.push(bestAdder);
          currentPyramid = applyAdderToPyramid(currentPyramid, bestAdder.data, bestAdder.position);
          console.log('Applied adder:', bestAdder);
          console.log('Updated pyramid:', currentPyramid);
  
          // Remove the used adder from remainingAdders
          remainingAdders = remainingAdders.filter(adder => 
            !(adder.data.every((val, idx) => val === bestAdder.data[idx]) && adder.cost === bestAdder.cost)
          );
        } else {
          console.log('Failed to select a compatible adder.');
          break;
        }
      }
  
      if (allSelectedAdders.length > 0) {
        setAdder(allSelectedAdders[allSelectedAdders.length - 1].data);
        setSelectedAdders(allSelectedAdders);
        setPyramid(currentPyramid);
      } else {
        setError('No adders were selected.');
      }
    } catch (error) {
      console.error('Error in fetchCustomAdder:', error);
      setError(`Failed to fetch custom adder: ${error.message}`);
    }
  };

  const applyAdder = () => {
    setPyramid(prevPyramid => applyAdderToPyramid(prevPyramid, adder, 0));
  };

  return (
    <div className="main-container">
      <h1>Custom Adder Visualizer</h1>
      {error && <div style={{color: 'red'}}>{error}</div>}
      <PyramidComponent levels={pyramid} />
      {adder.length > 0 && (
        <AdderComponent adder={adder} applyAdder={applyAdder} />
      )}
      <button onClick={fetchCustomAdder}>Fetch Custom Adder</button>
      {selectedAdders.length > 0 && (
        <div>
          <h2>Selected Adders:</h2>
          <ul>
            {selectedAdders.map((selectedAdder, index) => (
              <li key={index}>
                Cost: {selectedAdder?.cost ?? 'N/A'}, Adder Data: {JSON.stringify(selectedAdder?.data ?? [])}, Position: {selectedAdder?.position ?? 'N/A'}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default MainComponent;